from pathlib import Path
p=Path('flower-game/dist/index.html')
s=p.read_text(encoding='utf-8')
s=s.replace('iGEM · HP 科普试玩版','iGEM · HP 共创版 2.0')
s=s.replace('<div class="game-layout">','''<nav class="hp-nav" aria-label="共创工具"><button data-open="evidence">实验依据</button><button data-open="updates">你们说 / 我们改</button><button data-open="participate">留下建议</button></nav>
<div class="research-choice"><div><span class="eyebrow">你的研究决定 · 不影响游戏分数</span><h2>你会考虑褪黑素保鲜方案吗？</h2><p>可以先看证据，也可以保留意见。随时修改，不设标准答案。</p></div><div class="decision-buttons" id="decisions"><button data-decision="consider" aria-pressed="false">愿意进一步了解</button><button data-decision="wait" aria-pressed="false">需要更多证据</button><button data-decision="decline" aria-pressed="false">暂不考虑</button></div><p id="decision-note" aria-live="polite">尚未选择，也可以直接开始养花。</p></div>
<div class="game-layout">''')
s=s.replace('同期参考 · 只放清水，不再养护','模拟参考 · 此后不养护（非实验对照）')
s=s.replace('<div><strong id="final-diff"></strong><span>高于未养护参考</span></div>','<div><strong id="final-diff"></strong><span>已完成的养护天数</span></div>')
s=s.replace('<div class="result-note">给 HP 的讨论题：如果这是你的花店，你最在意保鲜效果、成本，还是使用方便？</div>','''<div class="result-note" id="decision-summary"></div><button class="primary" id="result-feedback">让团队听到你的想法 →</button><button class="text-button" data-open="evidence">看看哪些结论有证据</button>''')
s=s.replace('这是一局教学模拟，分差不能用来证明褪黑素的真实效果。','鲜活度只由虚构的养护规则计算。你的研究态度不加分、不扣分，不代表购买行为。')
s=s.replace('<script src="game.js"></script>', '''<dialog id="evidence"><button class="close" data-close="evidence" aria-label="关闭实验依据">×</button><span class="eyebrow">RESPONSIBILITY · 证据与边界</span><h2>知道了什么，还缺什么？</h2><article class="evidence-card"><span class="tag">文献证据</span><h3>褪黑素与鲜切花衰老</h3><p>2022 年的一项鲜切玫瑰研究观察到部分褪黑素处理改善瓶插表现。花材、浓度和处理条件会影响结果，不能直接推广到所有花或我们的产品。</p><a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC9609555/" target="_blank" rel="noreferrer">查看原始论文 ↗</a></article><article class="evidence-card"><span class="tag pending">团队数据 · 尚未接入</span><h3>我们的配方有效吗？</h3><p>这里尚无可核验的团队原始实验数据，所以不展示延长天数、成功率或最佳浓度。</p><dl><dt>生产端</dt><dd>工程菌产量、产物鉴定和纯度：待提供。</dd><dt>应用端</dt><dd>花种、样本量、对照、浓度、处理方式、瓶插寿命及波动：待提供。</dd></dl><p>购买的标准褪黑素、发酵液和纯化产物的结果不能互相替代。没测过的养护组合，也不能标成实测效果。</p></article><article class="evidence-card"><span class="tag">游戏模拟</span><p>7 天、鲜活度和养护加减分均为虚构规则。褪黑素选择不参与计分；游戏无法证明功效、安全性、环保性或真实购买意愿。</p></article></dialog>
<dialog id="participate"><button class="close" data-close="participate" aria-label="关闭反馈">×</button><span class="eyebrow">REFLECTION · 你的经验很重要</span><h2>下一步，你希望我们做什么？</h2><p>全部可跳过。不填写也能玩。回答只在当前页面临时保留，不会自动上传；刷新即清空。导出后，你可以自行决定是否交给团队。</p><form id="feedback-form"><label>你接触鲜花的身份<select name="role"><option value="">不回答</option><option>消费者</option><option>花店从业者</option><option>种植或物流从业者</option><option>学生或教育工作者</option><option>其他</option></select></label><label>你最希望补充哪类证据？<select name="need"><option value="">不回答</option><option>不同花种的保鲜效果</option><option>使用安全与产物质控</option><option>成本与价格</option><option>操作步骤与时间</option><option>环境影响</option><option>其他或不确定</option></select></label><label>哪里让你困惑，或不符合现实？<textarea name="confusion" maxlength="600" placeholder="请不要填写姓名、联系方式等个人信息"></textarea></label><label>如果只能改一件事，你会改什么？为什么？<textarea name="suggestion" maxlength="600" placeholder="不同意、暂不采用，也都是有价值的意见"></textarea></label><label class="consent"><input type="checkbox" name="consent">我自愿将本次回答与游戏选择导出为文件，自行决定是否分享。</label><button type="submit" class="primary">导出我的反馈文件</button><p id="export-status" role="status"></p></form><p class="small">没有反馈服务器，团队尚未收到你的回答。正式活动的数据收集和参与安排需由组织者另行说明。</p></dialog>
<dialog id="updates"><button class="close" data-close="updates" aria-label="关闭更新">×</button><span class="eyebrow">RESPONSIVENESS · 改变要留下记录</span><h2>你们说 / 我们改</h2><article class="evidence-card"><span class="tag">已完成 · 版本 2.0</span><h3>先让选择更公正</h3><p><strong>来源：</strong>项目负责人的本轮设计讨论，并非外部玩家调研。</p><p><strong>发现：</strong>把褪黑素直接写成加分卡，容易把游戏奖励误当成研究证据。</p><p><strong>改动：</strong>研究态度与计分分开；去掉“加量必扣分”；新增实验依据、可跳过反馈和本地导出。</p><p><strong>待复核：</strong>玩家能否分清模拟与实测？是否能自由表达不采用的理由？尚未开展玩家复测。</p></article><article class="evidence-card"><span class="tag pending">等待第一轮参与</span><h3>下一条改变，由你参与</h3><p>尚未收到并验证外部玩家反馈，暂无采纳成果。团队后续应记录：反馈来源 → 具体问题 → 采纳或不采纳的理由 → 实验 / 产品 / 沟通改动 → 回访结果。</p></article></dialog>
<script src="game.js"></script>''')
p.write_text(s,encoding='utf-8')
p=Path('flower-game/dist/game.js');s=p.read_text(encoding='utf-8')
a=s.index('const ACTIONS=');b=s.index('let state;',a)
s=s[:a]+'''const ACTIONS=[
{id:'water',icon:'💧',name:'换一瓶清水',desc:'关注水质与吸水',lesson:'你关注了基础养护。模拟分数不代表真实延长天数。'},
{id:'cool',icon:'🌤',name:'移到阴凉处',desc:'关注环境温度',lesson:'你把环境纳入了养护决定。'},
{id:'observe',icon:'🔎',name:'观察并记录',desc:'保留变化 · 不直接恢复鲜活度',lesson:'观察不直接恢复状态，但能帮助发现问题。'},
{id:'consult',icon:'📖',name:'查阅实验依据',desc:'了解证据 · 不直接恢复鲜活度',lesson:'查证有助于判断，但不会直接改变花的状态。'}];
const DECISIONS={consider:'愿意进一步了解',wait:'需要更多证据',decline:'暂不考虑'};
let decision=null;
''' + s[b:]
s=s.replace("if(has('melatonin'))loss-=5;if(has('extra'))loss+=3;",'')
s=s.replace("const lesson=has('extra')?ACTIONS[3].lesson:has('melatonin')?ACTIONS[2].lesson:has('water')?ACTIONS[0].lesson:ACTIONS[1].lesson;","const lesson=has('consult')?ACTIONS[3].lesson:has('observe')?ACTIONS[2].lesson:has('water')?ACTIONS[0].lesson:ACTIONS[1].lesson;")
s=s.replace("text:'褪黑素方案着眼于衰老过程。它和换水、降温，各自解决什么问题？'","text:'点开“实验依据”，看看文献与团队数据有什么不同。你可以调整研究态度，这不影响分数。'")
a=s.index('function showResult()');b=s.index("$('actions').addEventListener",a)
s=s[:a]+'''function showResult(){
$('result-title').textContent=state.fresh>=60?'花束挑战完成，聊聊你的选择。':'花期报告到了，下次可以换个策略。';
$('result-description').textContent='分数描述的是本局虚构养护结果，不评价你对新技术的态度。';
$('final-score').textContent=state.fresh;$('final-diff').textContent=state.history.length;
const water=state.history.filter(h=>h.actions.includes('water')).length;
const cool=state.history.filter(h=>h.actions.includes('cool')).length;
$('result-lesson').textContent=`你选择了 ${water} 次换水、${cool} 次调整环境。研究方案尚缺团队实测证据，不能从本局得出其效果。`;
$('decision-summary').textContent=decision?`你的研究态度：${DECISIONS[decision]}。这项选择没有标准答案。你希望看到什么证据，或改变哪些条件？`:'你还没有选择研究态度。可以继续保留判断，也可以告诉团队你需要什么。';
$('result').showModal();}
''' + s[b:]
s=s.replace("select(id);document.querySelector", "select(id);if(id==='consult'&&state.selected.includes(id))$('evidence').showModal();document.querySelector")
s+='''
function openPanel(id){if($('result').open)$('result').close();$(id).showModal();}
document.querySelectorAll('[data-open]').forEach(b=>b.addEventListener('click',()=>openPanel(b.dataset.open)));
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).close()));
$('result-feedback').addEventListener('click',()=>openPanel('participate'));
$('decisions').addEventListener('click',e=>{const b=e.target.closest('[data-decision]');if(!b)return;decision=b.dataset.decision;document.querySelectorAll('[data-decision]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.decision===decision)));$('decision-note').textContent=`已记录本页选择：${DECISIONS[decision]}。不会影响鲜活度，也不会自动发送。`;});
$('feedback-form').addEventListener('submit',e=>{e.preventDefault();const data=new FormData(e.target);if(!data.get('consent')){$('export-status').textContent='请先确认自愿导出，或者关闭窗口继续游戏。';return;}
const report={version:'2.0',kind:'voluntary-local-feedback',notice:'教学模拟；研究态度不参与计分；不是疗效或购买行为数据',role:data.get('role'),evidenceNeeded:data.get('need'),confusion:data.get('confusion'),suggestion:data.get('suggestion'),researchDecision:decision?DECISIONS[decision]:null,completed:state.done,daysPlayed:state.day,gameHistory:state.history};
const blob=new Blob([JSON.stringify(report,null,2)],{type:'application/json;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='花期守护者-我的反馈.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);$('export-status').textContent='已请求浏览器下载。文件只保存到你的设备，未提交给团队；你可以自行分享或删除。';});
'''
p.write_text(s,encoding='utf-8')
